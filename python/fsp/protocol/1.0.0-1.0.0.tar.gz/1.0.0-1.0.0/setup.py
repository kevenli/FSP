
from setuptools import setup

setup(
    name='1.0.0',
    version='1.0.0',
    packages=[''],
    url='github.com/netsaj',
    license='ISC',
    author='internal',
    author_email='me@localhost',
    description=''
)
        